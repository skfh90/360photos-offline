"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.signatureV4CrtContainer = void 0;
exports.signatureV4CrtContainer = {
    CrtSignerV4: null,
};
