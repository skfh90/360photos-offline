import { RequestPresigner, RequestSigner } from "@smithy/types";
export type OptionalCrtSignerV4 = {
  new (options: any): RequestPresigner & RequestSigner;
};
export declare const signatureV4CrtContainer: {
  CrtSignerV4: null | OptionalCrtSignerV4;
};
