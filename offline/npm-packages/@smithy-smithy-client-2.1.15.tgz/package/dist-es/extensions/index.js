export * from "./defaultExtensionConfiguration";
