# Installation
> `npm install --save @types/hammerjs`

# Summary
This package contains type definitions for Hammer.js (http://hammerjs.github.io/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/hammerjs.

### Additional Details
 * Last updated: Sat, 16 Sep 2023 08:06:32 GMT
 * Dependencies: none
 * Global values: `Hammer`, `HammerInput`, `MouseInput`, `PointerEventInput`, `SingleTouchInput`, `TouchAction`, `TouchInput`, `TouchMouseInput`

# Credits
These definitions were written by [Han Lin Yap](https://github.com/codler).
