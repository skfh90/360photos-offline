export * from "./EventStreamSerdeConfig";
