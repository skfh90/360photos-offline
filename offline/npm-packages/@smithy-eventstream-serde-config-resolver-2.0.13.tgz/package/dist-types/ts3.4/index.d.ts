/**
 * @internal
 */
export * from "./EventStreamSerdeConfig";
