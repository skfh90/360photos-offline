/**
 * @internal
 */
export * from "./EventStreamSerdeConfig";
