"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.resolveLocationConstraintConfig = void 0;
function resolveLocationConstraintConfig(input) {
    return { ...input };
}
exports.resolveLocationConstraintConfig = resolveLocationConstraintConfig;
