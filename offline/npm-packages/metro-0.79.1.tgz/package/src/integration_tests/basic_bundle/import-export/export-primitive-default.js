/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * @format
 *
 */

"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true,
});
exports.foo = exports.default = void 0;
var _default = "export-primitive-default: DEFAULT";
exports.default = _default;
const foo = "export-primitive-default: FOO";
exports.foo = foo;
