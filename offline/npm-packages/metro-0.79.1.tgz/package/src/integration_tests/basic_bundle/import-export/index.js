/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * @format
 *
 */

"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true,
});
exports.asyncImportESM = exports.asyncImportCJS = void 0;
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function () {
    return _export4.foo;
  },
});
exports.extraData = void 0;
Object.defineProperty(exports, "namedDefaultExported", {
  enumerable: true,
  get: function () {
    return _export3.default;
  },
});
var _export = _interopRequireWildcard(require("./export-1"));
var importStar = _interopRequireWildcard(require("./export-2"));
var _exportNull = require("./export-null");
var _exportPrimitiveDefault = _interopRequireWildcard(
  require("./export-primitive-default")
);
var _export3 = _interopRequireDefault(require("./export-3"));
var _export4 = require("./export-4");
function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}
function _getRequireWildcardCache(nodeInterop) {
  if (typeof WeakMap !== "function") return null;
  var cacheBabelInterop = new WeakMap();
  var cacheNodeInterop = new WeakMap();
  return (_getRequireWildcardCache = function (nodeInterop) {
    return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
  })(nodeInterop);
}
function _interopRequireWildcard(obj, nodeInterop) {
  if (!nodeInterop && obj && obj.__esModule) {
    return obj;
  }
  if (obj === null || (typeof obj !== "object" && typeof obj !== "function")) {
    return { default: obj };
  }
  var cache = _getRequireWildcardCache(nodeInterop);
  if (cache && cache.has(obj)) {
    return cache.get(obj);
  }
  var newObj = {};
  var hasPropertyDescriptor =
    Object.defineProperty && Object.getOwnPropertyDescriptor;
  for (var key in obj) {
    if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
      var desc = hasPropertyDescriptor
        ? Object.getOwnPropertyDescriptor(obj, key)
        : null;
      if (desc && (desc.get || desc.set)) {
        Object.defineProperty(newObj, key, desc);
      } else {
        newObj[key] = obj[key];
      }
    }
  }
  newObj.default = obj;
  if (cache) {
    cache.set(obj, newObj);
  }
  return newObj;
}
const extraData = {
  foo: _exportNull.foo,
  importStar,
  myDefault: _export.default,
  myFoo: _export.foo,
  myFunction: (0, _export.myFunction)(),
  primitiveDefault: _exportPrimitiveDefault.default,
  primitiveFoo: _exportPrimitiveDefault.foo,
};
exports.extraData = extraData;
const asyncImportCJS = import("./export-5");
exports.asyncImportCJS = asyncImportCJS;
const asyncImportESM = import("./export-6");
exports.asyncImportESM = asyncImportESM;
