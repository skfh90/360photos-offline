/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 *
 * @format
 * @oncall react_native
 */

"use strict";

const { getJsOutput } = require("./js");
function getSourceMapInfo(module, options) {
  return {
    ...getJsOutput(module).data,
    isIgnored: options.shouldAddToIgnoreList(module),
    path: module.path,
    source: options.excludeSource ? "" : getModuleSource(module),
  };
}
function getModuleSource(module) {
  if (getJsOutput(module).type === "js/module/asset") {
    return "";
  }
  return module.getSource().toString();
}
module.exports = getSourceMapInfo;
