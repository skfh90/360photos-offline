/**
 * @internal
 */
export * from "./fromProcess";
