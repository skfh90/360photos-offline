# Installation
> `npm install --save @types/react-native-sqlite-storage`

# Summary
This package contains type definitions for react-native-sqlite-storage (https://github.com/andpor/react-native-sqlite-storage).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/react-native-sqlite-storage.

### Additional Details
 * Last updated: Wed, 08 Nov 2023 11:06:41 GMT
 * Dependencies: none

# Credits
These definitions were written by [Sergei Dryganets](https://github.com/dryganets), and [Deividi Cavarzan](https://github.com/cavarzan).
