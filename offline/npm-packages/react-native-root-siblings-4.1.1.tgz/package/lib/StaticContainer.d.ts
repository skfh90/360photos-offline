import { Component } from 'react';
interface Props {
    shouldUpdate: boolean;
}
export default class extends Component<Props> {
    shouldComponentUpdate(nextProps: Props): boolean;
    render(): {} | null | undefined;
}
export {};
