import { Component, ReactChild, ReactNode } from 'react';
import RootController from './RootController';
interface RootSiblingsProps {
    controller: RootController;
    renderSibling?: (sibling: ReactNode) => ReactNode;
    children: ReactChild;
}
interface RootSiblingsState {
    siblings: Array<{
        id: string;
        element: ReactNode;
    }>;
}
export default class extends Component<RootSiblingsProps, RootSiblingsState> {
    constructor(props: RootSiblingsProps);
    componentDidMount(): void;
    componentDidUpdate(): void;
    componentWillUnmount(): void;
    private siblingsPool;
    private updatedSiblings;
    private unmounted;
    private commitChange;
    private invokeCallback;
    private renderSiblings;
    private wrapSibling;
    render(): JSX.Element;
}
export {};
