# Installation
> `npm install --save @types/react-native-video`

# Summary
This package contains type definitions for react-native-video (https://github.com/react-native-community/react-native-video).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/react-native-video.

### Additional Details
 * Last updated: Wed, 27 Sep 2023 07:12:04 GMT
 * Dependencies: [@types/react](https://npmjs.com/package/@types/react), [@types/react-native](https://npmjs.com/package/@types/react-native)
 * Global values: none

# Credits
These definitions were written by [HuHuanming](https://github.com/huhuanming), [Nekith](https://github.com/Nekith), and [Philip Frank](https://github.com/bananer).
