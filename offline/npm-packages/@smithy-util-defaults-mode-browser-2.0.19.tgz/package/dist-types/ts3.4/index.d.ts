/**
 * @internal
 */
export * from "./resolveDefaultsModeConfig";
